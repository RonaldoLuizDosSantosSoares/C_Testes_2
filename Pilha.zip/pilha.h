#ifndef PILHA_H INCLUDED
#define PILHA_H INCLUDED

template <typename Tipo>
struct Pilha{
    Tipo *v;
    int topo;
    int tammax;

    Pilha(int tamanho){
        tammax=tamanho;
        v = new Tipo[tammax];
        topo = -1;
    }

    void empilha(Tipo x){
        topo++;
        v[topo]=x;
    }

    Tipo desempilha(){
       Tipo temp = v[topo];
       topo--;
       return temp;
    }

    Tipo elementodotopo(){
        return v[topo];
    }
    bool pilhavazia(){
        return topo == -1;
    }

    bool pilhacheia(){
        return topo == tammax-1;
    }

};

#endif