#include <iostream>
#include "matriz.h"
using namespace std;

int main()
{
    cout << "Hello world!" << endl;

    //3 � a qtde de linhas
    //4 � a qtde de colunas
    //9 � o valor de preenchimento inicial
    Matriz<int> m1(5,8,0);
    m1.insere(3,4,5);
    //exibindo a matriz
    for(int i=0;i<m1.linha;i++){
        for(int j=0;j<m1.coluna;j++){
            cout<<m1.getValor(i,j)<<" ";
        }
        cout<<endl;
    }


    return 0;
}
