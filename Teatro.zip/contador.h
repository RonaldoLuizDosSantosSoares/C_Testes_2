#ifndef CONTADOR_H_INCLUDED
#define CONTADOR_H_INCLUDED

struct C
{

int contador = 0;

void adicao()
{
    contador++;
}

void tirar()
{
    if (contador>0)
    contador--;
}

int gettotal()
{
    return contador*5;
}


};


#endif
