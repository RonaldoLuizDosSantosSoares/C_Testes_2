/*

Nome do aluno: Ronaldo Luiz
Disciplina: Analise e desenvolvimento de sistemas
Matéria; Estrutura de dados

Anotações:

1 - venda  //vende um ingresso indicando qual posição a pessoa deseja ocupar (alocar essa variavel no vetor)
2 - devolução //permite à pessoa que devolva o ingresso que tinha comprado (buscar o ultimo valor que foi digitado no vetor)
3 - exibe  //Exibe da situação atual do teatro: Lugares ocupados, livres e quantidade vendida. (situação atual seria mostrar os valores através de um bool e mostrar se está livre ou não)
9 - fim de execução. (vou deixar como digito 4)

if(valor == vetor[posição])

*/

#include <iostream>
#include "ingresso.h"
#include "contador.h"

using namespace std;

int main()

{
    cout << "Bem vindo ao Teatro 2.0!!\n" << endl;
    cout << "Escolha uma das opções a seguir para prosseguir:\n";
    
    int tamanhoteatro = 100;
    
    L<int> lista(tamanhoteatro);
    
    C c1;
    
    int opcao;
    
    int num;
    
do{
        cout<<"1 - Comprar ingresso"<<endl;
        
        cout<<"2 - Reembolsar ingresso"<<endl;
        
        cout<<"3 - Exibir situação atual do teatro"<<endl;
        
        cout<<"9 - Sair do programa\n"<<endl;
        
        cin>>opcao;
        
        switch(opcao)
        
        {
            
            
            case 1:
            if (lista.cheio())
            {
                system("clear||cls");
                cout<<"O Teatro está cheio no momento\n"<<endl;
                cout<<"Deseja realizar mais alguma ação?\n";
                
            }
            else
            {
                system("clear||cls");
                cout<<"O bilhete custa 5 reais!\n";
                cout<<"Agora digite o lugar:\n";
                cin>>num;
                
            c1.adicao();
   
            lista.inserir(num);
                system("clear||cls");
                cout<<"Ingresso comprado com sucesso!\n";
                cout<<"Deseja fazer mais alguma coisa?\n";
            }
            break;
            
            case 2:
            if(lista.vazio())
            {
                system("clear||cls");
                cout<<"O Teatro está vazio e não há nenhum ingresso para reembolsar!"<<endl;
                cout<<"Deseja realizar mais alguma ação?\n";
            }
            else
            {
            c1.tirar();
                system("clear||cls");
                cout<<"Lugar removido: \n"<<lista.ult()<<endl;
                lista.remover();
                cout<<"Bilhete reembolsado com sucesso!\n";
                cout<<"Deseja fazer mais alguma coisa?\n";
            }
            break;
            
            case 3:
            if (lista.vazio())
            {
                system("clear||cls");
                cout<<"Teatro vazio!\n";
                cout<<"Deseja realizar mais alguma ação?\n";
            
            }
            else
            {   
                system("clear||cls");
                cout<<"Cadeira(s) ocupadas:\n";
                for (int i=0;i<=lista.lugar;i++){
                    cout<<lista.lista[i]<<" ";
                }
                cout<<endl;
                cout<<"Quantidade arrecadada em reais:\n"<<c1.gettotal()<<endl; // valor em reais
                cout<<"Deseja fazer mais alguma coisa?\n";
            }
            break;
            
            case 9:
            system("clear||cls");
            cout<<"Fim do programa!\n";
            cout<<"Volte sempre!!\n";
            break;
            
            default:
            cout<<"Comando inválido! digite novamente\n"<<endl<<endl;
            break;
            
        }
    }while(opcao!=9);

}

// observações, ficou faltando mostrar ao usuário se o lugar que ele escolheu já estava ocupado
// então pela minha lógica a pessoa que for utilizar o programa terá que exibir a situação atual do teatro antes para a pessoa escolher o lugar sem erro!
// (igual no cinema)
