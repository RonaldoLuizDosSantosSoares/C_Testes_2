#include <iostream>
using namespace std;
#include "pilha_ligada.h"

int main()
{
    Pilha<int> p;
    int opc, x;
    do{
        cout<<"1-empilha"<<endl;
        cout<<"2-desempilha"<<endl;
        cout<<"3-elemento do topo"<<endl;
        cout<<"4-exibir a pilha"<<endl;
        cout<<"9-fim"<<endl;
        cout<<"Selecione:";
        cin>>opc;
        switch(opc){
        case 1:
            cout<<"Digite o valor:";
            cin>>x;
            if(p.empilha(x)){
                cout<<"Sucesso"<<endl<<endl;
            }
            else{
                cout<<"pilha cheia!!!!"<<endl;
            }
            break;
        case 2:
            if(p.pilhavazia()){
                cout<<"pilha vazia!"<<endl<<endl;
            }
            else{
                cout<<"Desempilhado:"<<p.elementodotopo()<<endl<<endl;
                p.desempilha();
            }
            break;
        case 3:
                if(p.pilhavazia()){
                cout<<"pilha vazia!"<<endl<<endl;
            }
            else{
                cout<<"Elemento do topo:"<<p.elementodotopo()<<endl<<endl;
            }
            break;
        case 4:
            cout<<"Elemento da pilha:";
            if(p.pilhavazia()){

                cout<<"Pilha vazia!"<<endl;
            }
            else{
                Node<int> *aux = p.topo;
                while(aux != NULL){
                    cout<<aux->info<<" ";
                    aux = aux->prox;
                }
                cout<<endl<<endl;
            }
            break;
        case 9:
            cout<<"Fim";
            break;
        default:
            cout<<"opcao invalida"<<endl<<endl;
            break;
        }
    }while(opc != 9);
    return 0;
}
