#ifndef LISTALINEAR_V2_H_INCLUDED
#define LISTALINEAR_V2_H_INCLUDED


template <typename Tipo>
struct ListaLinear{
    Tipo *lista;
    int tamanho;
    int p; //posicao


    ListaLinear(int tam){
        tamanho = tam;
        lista = new Tipo[tamanho];
        p = -1;
    }

    void insere(Tipo x){
        p++;
        lista[p]=x;
    }

    void remover(){
        p--;
    }

    Tipo ultimodalista(){
        return lista[p];
    }

    Tipo primeirodalista(){
        return lista[0];
    }

    bool listacheia(){
        return p == tamanho-1;
    }

    bool listavazia(){
        return p == -1;
    }

};


#endif // LISTALINEAR_V2_H_INCLUDED
