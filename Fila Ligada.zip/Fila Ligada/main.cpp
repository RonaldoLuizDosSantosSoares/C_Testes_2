#include <iostream>
#include "filaligada.h"

using namespace std;

int main()
{
    cout << "Hello world Fila em Alocacao Sequencial!" << endl;
    Fila<int> f;

    int opc, x;
    do{
        cout<<"1 - insere"<<endl;
        cout<<"2 - remove"<<endl;
        cout<<"3 - primeiro"<<endl;
        cout<<"4 - exibe a fila"<<endl;
        cout<<"9 - fim"<<endl;
        cout<<"Selecione:";
        cin>>opc;
        switch(opc){
        case 1:
            cout<<"Digite do valor:";
            cin>>x;
            if (f.insere(x)){
                cout<<"sucesso !!!"<<endl<<endl;
            }
            else{
                cout<<"Fila cheia....!!!"<<endl;
            }
            break;
        case 2:
            if (f.filavazia()){
                cout<<"Fila vazia!!!"<<endl<<endl;
            }
            else{
                cout<<"Removido:"<<f.remover()<<endl<<endl;
            }
            break;
        case 3:
            if (f.filavazia()){
                cout<<"Fila vazia!!!"<<endl<<endl;
            }
            else{
                cout<<"Primeiro da vila:"<<f.primeiro()<<endl<<endl;
            }
            break;
        case 4:
            if (f.filavazia()){
                cout<<"Fila vazia!!!"<<endl<<endl;
            }
            else{
                cout<<"Elementos da Fila: ";
                Node<int> *aux = f.inic;
                while (aux != NULL){
                    cout<<aux->info<< " ";
                    aux = aux->prox;
                }
            }
            cout<<endl<<endl;
            break;
        case 9:
            cout<<"Fim!!!"<<endl;
            break;
        default:
            cout<<"opcao invalida!!!"<<endl;
            break;
        }
    }while (opc != 9);
    return 0;
}

