/* Anotações:

colocar um contador para verificar o vetor e dizer se os lugares estão vazios ou não \\ ou o usuario selecionar o proprio vetor
uma variavel ou contador calculando a quantidade de ingresso vendido?

PS: Me espelhei na Lista Linear V2


*/


#ifndef INGRESSO_H_INCLUDED
#define INGRESSO_H_INCLUDED


template <typename T>

struct L

{

    T *lista;
    int tamanho;
    int lugar;


    L(int tamanho){
        lista = new T[tamanho];
        lugar = -1;
    }

    void inserir(T num){
        lugar++;
        lista[lugar]=num;
    }

    void remover(){
        lugar--;
    }

    T ult(){
        return lista[lugar];
    }

    T pri(){
        return lista[0];
    }
    

    bool cheio(){
        return lugar == tamanho-1;
    }

    bool vazio(){
        return lugar == -1;
    }

};


#endif
