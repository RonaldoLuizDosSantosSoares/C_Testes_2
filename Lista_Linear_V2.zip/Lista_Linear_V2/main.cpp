#include <iostream>
#include "listalinear_v2.h"
using namespace std;
int main()
{
    cout << "Lista Linear V2" << endl;
    int t; //tamanho do vetor
    cout<<"Digite o tamanho da lista:";
    cin>>t;
    ListaLinear<int> lista(t);
    int opc;
    int x;
    do{
        cout<<"1-insere"<<endl;
        cout<<"2-remove"<<endl;
        cout<<"3-exibe a lista"<<endl;
        cout<<"9-fim"<<endl;
        cout<<"Selecione:";
        cin>>opc;
        switch(opc){
        case 1:
            if (lista.listacheia()){
                cout<<"Lista Cheia"<<endl<<endl;
            }
            else{
                cout<<"Digite o valor:";
                cin>>x;
                lista.insere(x);
                cout<<"insercao com sucesso"<<endl<<endl;
            }
            break;
        case 2:
            if(lista.listavazia()){
                cout<<"Lista vazia..."<<endl<<endl;
            }
            else{
                cout<<"Removido: "<<lista.ultimodalista()<<endl;
                lista.remover();
            }
            break;
        case 3:
            if (lista.listavazia()){
                cout<<"Lista vazia..."<<endl<<endl;
            }
            else{
                cout<<"Elementos da Lista:";
                for (int i=0;i<=lista.p;i++){
                    cout<<lista.lista[i]<<" ";
                }
                cout<<endl;
            }
            break;
        case 9:
            cout<<"Fim...."<<endl;
            break;
        default:
            cout<<"opcao invalida"<<endl<<endl;
            break;
        }
    }while(opc!=9);

    return 0;
}
