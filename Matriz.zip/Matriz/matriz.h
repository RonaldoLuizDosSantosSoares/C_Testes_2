#ifndef MATRIZ_H_INCLUDED
#define MATRIZ_H_INCLUDED

template <typename Tipo>
struct Matriz{
    int linha;
    int coluna;
    Tipo *v;

    Matriz(int lin, int col, Tipo t){
        linha=lin;
        coluna=col;
        v = new Tipo[linha * coluna];
        for (int i=0;i<linha;i++){
            for(int j=0;j<coluna;j++){
                v[i*coluna+j] = t;
            }
        }
    }

    void insere(int lin, int col, Tipo x){
        v[lin*coluna+col]=x;
    }

    Tipo getValor(int lin, int col){
        return v[lin*coluna+col];
    }

};




#endif // MATRIZ_H_INCLUDED
