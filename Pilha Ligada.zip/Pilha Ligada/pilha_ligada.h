#ifndef PILHA_LIGADA_H_INCLUDED
#define PILHA_LIGADA_H_INCLUDED



template <typename Tipo>
struct Node{
    Tipo info;
    Node *prox;
};

template <typename Tipo>
struct Pilha{
    Node<Tipo> *topo;

    Pilha(){
        topo = NULL;
    }

    ~Pilha(){
        while( !pilhavazia() ){
           desempilha();
        }
    }

    bool empilha(Tipo x){
        bool v = true;
        Node<Tipo> *aux = new Node<Tipo>; //0
        if(aux == NULL){
            v = false;
        }
        else{
            aux->info = x;
            aux->prox = topo; //1
            topo = aux; //2
        }
        return  v;
    }

    Tipo elementodotopo(){
        return topo->info;
    }

    void desempilha(){
       Node<Tipo> *aux = topo; //1
       topo = topo->prox; //2
       delete aux;
    }

    bool pilhavazia(){
        return topo == NULL;
    }
};


#endif // PILHA_LIGADA_H_INCLUDED
