#include <iostream>
#include "fila.h"
using namespace std;

int main()
{
    cout << "Hello world Fila em Alocacao Sequencial!" << endl;
    int tamanho;
    cout<<"Digite o tamanho de sua fila:";
    cin>>tamanho;
    Fila<int> f(tamanho);
    int opc, x;
    do{
        cout<<"1 - insere"<<endl;
        cout<<"2 - remove"<<endl;
        cout<<"3 - primeiro"<<endl;
        cout<<"4 - exibe a fila"<<endl;
        cout<<"9 - fim"<<endl;
        cout<<"Selecione:";
        cin>>opc;
        switch(opc){
        case 1:
            if(f.filacheia()){
                cout<<"fila cheia!"<<endl<<endl;
            }
            else{
                cout<<"Digite o valor:";
                cin>>x;
                f.insere(x);
                cout<<"Sucesso!!!"<<endl<<endl;
            }
            break;
        case 2:
            if (f.filavazia()){
                cout<<"Fila vazia!!!"<<endl<<endl;
            }
            else{
                cout<<"Removido:"<<f.remover()<<endl<<endl;
            }
            break;
        case 3:
            if (f.filavazia()){
                cout<<"Fila vazia!!!"<<endl<<endl;
            }
            else{
                cout<<"Primeiro da vila:"<<f.primeiro()<<endl<<endl;
            }
            break;
        case 4:
            if (f.filavazia()){
                cout<<"Fila vazia!!!"<<endl<<endl;
            }
            else{
                cout<<"Elementos da Fila: ";
                if (f.inic <= f.fim){
                    for(int i=f.inic;i<=f.fim;i++){
                        cout<<f.v[i]<<" ";
                    }
                }
                else{
                    for(int i=f.inic; i < f.tamanho; i++){
                        cout<<f.v[i]<<" ";
                    }
                    for(int i=0; i <= f.fim; i++){
                            cout<<f.v[i]<<" ";
                    }
                }
            }
            cout<<endl<<endl;
            break;
        case 9:
            cout<<"Fim!!!"<<endl;
            break;
        default:
            cout<<"opcao invalida!!!"<<endl;
            break;
        }
    }while (opc != 9);
    return 0;
}
